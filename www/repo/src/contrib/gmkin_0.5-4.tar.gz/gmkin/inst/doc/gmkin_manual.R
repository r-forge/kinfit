## ----, include = FALSE---------------------------------------------------
library(knitr)
opts_chunk$set(tidy = FALSE, cache = TRUE)

