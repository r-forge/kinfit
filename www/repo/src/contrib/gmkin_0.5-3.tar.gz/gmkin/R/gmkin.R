gmkin <- function() {
  load_app(system.file("GUI/gmkin.R", package = "gmkin"))
}
